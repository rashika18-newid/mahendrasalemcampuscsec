<?php
if (session_status()===PHP_SESSION_NONE) session_start();
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/includes/functions.php';
if (!isset($_SESSION['user_id'])) { header('Location: ./login.php'); exit; }
$uid = (int)$_SESSION['user_id'];
$counts = ['total'=>0,'Pending'=>0,'In Progress'=>0,'Resolved'=>0,'Closed'=>0];
$recent = []; $byCat = [];
try{
    $stmt = $conn->prepare("SELECT status, COUNT(*) AS c FROM complaints WHERE user_id = ? AND is_deleted = 0 GROUP BY status");
    $stmt->execute([$uid]);
    while($r=$stmt->fetch()){ $counts[$r['status']]=(int)$r['c']; $counts['total']+=(int)$r['c']; }
    $stmt = $conn->prepare("SELECT id, category, subject, status, created_at FROM complaints WHERE user_id = ? AND is_deleted = 0 ORDER BY created_at DESC LIMIT 5");
    $stmt->execute([$uid]); $recent=$stmt->fetchAll();
} catch(Exception $e){}
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Dashboard</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,sans-serif;background:#f6f7fb}
.nav{background:#fff;padding:14px 24px;display:flex;justify-content:space-between;box-shadow:0 1px 3px rgba(0,0,0,.1)}
.nav a{margin:0 10px;text-decoration:none;color:#333;font-weight:600}
.stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;padding:24px}
.stat-card{background:#fff;padding:20px;border-radius:12px;display:flex;gap:14px;box-shadow:0 2px 8px rgba(0,0,0,.05)}
.card{background:#fff;margin:0 24px 24px;padding:20px;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.05)}
.badge{padding:4px 10px;border-radius:20px;font-size:12px;font-weight:700}
.badge-pending{background:#fef3c7;color:#92400e}.badge-progress{background:#dbeafe;color:#1e40af}.badge-resolved{background:#dcfce7;color:#166534}
.table{width:100%;border-collapse:collapse}.table th,.table td{padding:10px;text-align:left;border-bottom:1px solid #eee}
.btn{padding:8px 14px;background:#667eea;color:#fff;border-radius:8px;text-decoration:none;font-weight:600}
@media(max-width:700px){.stat-grid{grid-template-columns:1fr 1fr}}
</style></head><body>
<div class="nav"><div><strong>ResolveDesk</strong> | Welcome <?= e($_SESSION['user_name'])?></div><div><a href="./dashboard.php">Dashboard</a><a href="./my_complaints.php">My Complaints</a><a href="./submit_complaint.php">+ New</a><a href="./logout.php">Logout</a></div></div>
<div class="stat-grid">
<div class="stat-card"><div><p>Total</p><h2><?= (int)$counts['total']?></h2></div></div>
<div class="stat-card"><div><p>Pending</p><h2><?= (int)$counts['Pending']?></h2></div></div>
<div class="stat-card"><div><p>In Progress</p><h2><?= (int)$counts['In Progress']?></h2></div></div>
<div class="stat-card"><div><p>Resolved</p><h2><?= (int)$counts['Resolved']?></h2></div></div>
</div>
<div class="card"><h2>Recent Complaints</h2>
<?php if(!$recent):?><p>No complaints yet. <a class="btn" href="./submit_complaint.php">Submit first complaint</a></p>
<?php else:?><table class="table"><tr><th>Ref</th><th>Subject</th><th>Status</th><th>Date</th></tr><?php foreach($recent as $r):?><tr><td><?= e(complaint_ref($r['id']))?></td><td><?= e($r['subject'])?></td><td><span class="badge <?= e(status_badge_class($r['status']))?>"><?= e($r['status'])?></span></td><td><?= e($r['created_at'])?></td></tr><?php endforeach;?></table><?php endif;?>
</div>
</body></html>
