<?php
// My Complaints — search + filters + pagination, scoped to the logged-in student.
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/student_auth.php';

$uid = (int)$_SESSION['user_id'];

// ---- Filters (GET, safe defaults) ----
$search   = trim($_GET['q'] ?? '');
$category = trim($_GET['category'] ?? '');
$status   = trim($_GET['status'] ?? '');
$page     = max(1, (int)($_GET['page'] ?? 1));
$perPage  = 8;
$offset   = ($page - 1) * $perPage;

$where = ['c.user_id = ?', 'c.is_deleted = 0'];
$types = 'i';
$params = [$uid];

if ($search !== '') {
    $where[] = '(c.subject LIKE ? OR c.description LIKE ? OR c.id = ?)';
    $types .= 'ssi';
    $like = '%' . $search . '%';
    // If search is numeric, allow exact ID match; else 0 matches nothing.
    $idSearch = ctype_digit($search) ? (int)$search : 0;
    $params[] = $like; $params[] = $like; $params[] = $idSearch;
}
if ($category !== '' && is_valid_category($category)) { $where[] = 'c.category = ?'; $types .= 's'; $params[] = $category; }
if ($status !== '' && is_valid_status($status))       { $where[] = 'c.status = ?';   $types .= 's'; $params[] = $status; }

$whereSql = implode(' AND ', $where);

// Total count for pagination.
$sql = "SELECT COUNT(*) AS c FROM complaints c WHERE $whereSql";
$stmt = $conn->prepare($sql);
stmt_bind($stmt, $types, $params);
$stmt->execute();
$total = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
$stmt->close();
$totalPages = max(1, (int)ceil($total / $perPage));
if ($page > $totalPages) { $page = $totalPages; $offset = ($page - 1) * $perPage; }

// Page rows.
$sql = "SELECT c.id, c.category, c.subject, c.status, c.admin_response, c.created_at, c.updated_at
        FROM complaints c WHERE $whereSql ORDER BY c.created_at DESC LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$types2 = $types . 'ii';
$params2 = array_merge($params, [$perPage, $offset]);
stmt_bind($stmt, $types2, $params2);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

function qsa($overrides = []) {
    $q = array_merge($_GET, $overrides);
    // Drop empty values & reset page when filters change.
    foreach ($q as $k => $v) { if ($v === '' || $v === null) unset($q[$k]); }
    return '?' . http_build_query($q);
}

$page_title = 'My Complaints';
$page_subtitle = $total . ' complaint' . ($total === 1 ? '' : 's') . ' on your record.';
$active = 'my';
require_once __DIR__ . '/includes/header.php';
?>

<div class="card toolbar">
  <form class="toolbar-row" method="get" action="<?= BASE_URL ?>/my_complaints.php">
    <div class="search-box"><i class="fa-solid fa-magnifying-glass"></i><input type="search" name="q" placeholder="Search subject, description or ID…" value="<?= e($search) ?>"></div>
    <select name="category"><option value="">All categories</option><?php foreach (complaint_categories() as $cat): ?><option value="<?= e($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>><?= e($cat) ?></option><?php endforeach; ?></select>
    <select name="status"><option value="">All statuses</option><?php foreach (complaint_statuses() as $s): ?><option value="<?= e($s) ?>" <?= $status === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select>
    <button class="btn btn-primary" type="submit">Filter</button>
    <?php if ($search !== '' || $category !== '' || $status !== ''): ?><a class="btn btn-ghost" href="<?= BASE_URL ?>/my_complaints.php">Clear</a><?php endif; ?>
  </form>
</div>

<div class="card panel">
<?php if (!$rows): ?>
  <div class="empty"><div class="empty-icon"><i class="fa-regular fa-folder-open"></i></div><h3>No complaints found</h3><p>Try adjusting search or filters — or file a new complaint.</p><a class="btn btn-primary" href="<?= BASE_URL ?>/submit_complaint.php"><i class="fa-solid fa-plus"></i> Submit New Complaint</a></div>
<?php else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>Ref</th><th>Subject</th><th>Category</th><th>Date</th><th>Status</th><th>Admin response</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $c): ?>
      <tr>
        <td class="mono"><?= e(complaint_ref($c['id'])) ?></td>
        <td><strong><?= e(mb_strimwidth($c['subject'], 0, 48, '…')) ?></strong></td>
        <td><span class="cat-pill"><?= e($c['category']) ?></span></td>
        <td class="muted nowrap"><?= e(date('M j, Y', strtotime($c['created_at']))) ?></td>
        <td><span class="badge <?= e(status_badge_class($c['status'])) ?>"><?= e($c['status']) ?></span></td>
        <td class="muted"><?= $c['admin_response'] ? e(mb_strimwidth($c['admin_response'], 0, 60, '…')) : '<span class="dim">— awaiting review</span>' ?></td>
        <td><a class="btn btn-ghost btn-sm" href="<?= BASE_URL ?>/complaint_details.php?id=<?= (int)$c['id'] ?>">View</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php if ($totalPages > 1): ?>
  <div class="pagination">
    <?php if ($page > 1): ?><a class="page-btn" href="<?= e(qsa(['page' => $page - 1])) ?>"><i class="fa-solid fa-chevron-left"></i> Prev</a><?php endif; ?>
    <?php for ($p = 1; $p <= $totalPages; $p++): if ($totalPages > 7 && abs($p - $page) > 2 && $p !== 1 && $p !== $totalPages) continue; ?>
      <a class="page-btn<?= $p === $page ? ' current' : '' ?>" href="<?= e(qsa(['page' => $p])) ?>"><?= $p ?></a>
    <?php endfor; ?>
    <?php if ($page < $totalPages): ?><a class="page-btn" href="<?= e(qsa(['page' => $page + 1])) ?>">Next <i class="fa-solid fa-chevron-right"></i></a><?php endif; ?>
  </div>
  <?php endif; ?>
<?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
