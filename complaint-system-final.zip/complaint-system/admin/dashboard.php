<?php
if (session_status()===PHP_SESSION_NONE) session_start();
require_once __DIR__.'/../includes/functions.php';
if (!isset($_SESSION['user_id']) || $_SESSION['user_role']!=='admin'){ header('Location:../login.php'); exit; }
$data=json_decode(file_get_contents(__DIR__.'/../fake_db.json'),true);
$comps=$data['complaints']??[]; $total=count($comps);
$pending=count(array_filter($comps,fn($c)=>$c['status']=='Pending'));
$progress=count(array_filter($comps,fn($c)=>$c['status']=='In Progress'));
$resolved=count(array_filter($comps,fn($c)=>in_array($c['status'],['Resolved','Closed'])));
$recent=array_slice(array_reverse($comps),0,10);
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Admin Dashboard</title><style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,sans-serif;background:#f6f7fb}
.nav{background:#1e293b;color:#fff;padding:14px 24px;display:flex;justify-content:space-between}
.nav a{color:#fff;margin:0 10px;text-decoration:none;font-weight:600}
.stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;padding:24px}
.stat-card{background:#fff;padding:20px;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.05);text-align:center}
.stat-card h3{font-size:28px;margin:0}
.card{background:#fff;margin:0 24px 24px;padding:20px;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.05)}
.table{width:100%;border-collapse:collapse}.table th,.table td{padding:12px;text-align:left;border-bottom:1px solid #eee}
.badge{padding:4px 10px;border-radius:20px;font-size:12px;font-weight:700}
.badge-pending{background:#fef3c7;color:#92400e}.badge-progress{background:#dbeafe;color:#1e40af}.badge-resolved{background:#dcfce7;color:#166534}
@media(max-width:700px){.stat-grid{grid-template-columns:1fr 1fr}}
</style></head><body>
<div class="nav"><div><strong>ResolveDesk ADMIN</strong></div><div><a href="./dashboard.php">Dashboard</a><a href="./complaints.php">Complaints</a><a href="./users.php">Users</a><a href="../logout.php">Logout</a></div></div>
<div class="stat-grid">
<div class="stat-card"><p>Total</p><h3><?= $total?></h3></div>
<div class="stat-card"><p>Pending</p><h3><?= $pending?></h3></div>
<div class="stat-card"><p>In Progress</p><h3><?= $progress?></h3></div>
<div class="stat-card"><p>Resolved</p><h3><?= $resolved?></h3></div>
</div>
<div class="card"><h2>Recent Complaints</h2><table class="table"><thead><tr><th>Ref</th><th>User</th><th>Subject</th><th>Status</th><th>Date</th></tr></thead><tbody>
<?php foreach($recent as $c):?><tr><td>CMP<?= str_pad($c['id'],6,'0',STR_PAD_LEFT)?></td><td><?= e($c['user_name'])?></td><td><?= e($c['subject'])?></td><td><span class="badge badge-<?= strtolower(explode(' ', $c['status'])[0])?>"><?= e($c['status'])?></span></td><td><?= e($c['created_at'])?></td></tr><?php endforeach;?>
</tbody></table></div>
</body></html>
