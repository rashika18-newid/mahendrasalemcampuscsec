<?php
// ZERO-DRIVER DB - Works without pdo_mysql, pdo_sqlite, sqlite3
// For ByteXL hosting it will use MySQL, for workspace it uses fake file DB

$h_host = "db01.dbhost.dev"; $h_port = 5051; $h_db = "db_455pfrc7h"; $h_user = "user_455pfrc7h"; $h_pass = "p455pfrc7h";

$conn = null;

// Try real MySQL if available
if (in_array('mysql', PDO::getAvailableDrivers())) {
    try {
        $dsn = "mysql:host=$h_host;port=$h_port;dbname=$h_db;charset=utf8mb4";
        $conn = new PDO($dsn, $h_user, $h_pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
    } catch(Exception $e) {}
}

// Try SQLite if available
if (!$conn && in_array('sqlite', PDO::getAvailableDrivers())) {
    try {
        $dbFile = __DIR__. '/../complaint_system.db';
        $pdo = new PDO('sqlite:'.$dbFile);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT UNIQUE, password TEXT, role TEXT DEFAULT 'student', is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS complaints (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, category TEXT, subject TEXT, description TEXT, location TEXT, status TEXT DEFAULT 'Pending', admin_response TEXT, is_deleted INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS complaint_history (id INTEGER PRIMARY KEY AUTOINCREMENT, complaint_id INTEGER, admin_id INTEGER, old_status TEXT, new_status TEXT, comment TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $c = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
        if ($c == 0) {
            $pdo->exec("INSERT INTO users (name,email,password,role) VALUES ('Administrator','admin@college.edu','".password_hash('Admin@123', PASSWORD_DEFAULT)."','admin')");
            $pdo->exec("INSERT INTO users (name,email,password,role) VALUES ('Demo Student','student@college.edu','".password_hash('Student@123', PASSWORD_DEFAULT)."','student')");
        }
        $conn = $pdo;
    } catch(Exception $e) {}
}

// ULTIMATE FALLBACK - Pure PHP, no extension needed!
if (!$conn) {
    class FakeDB {
        public $file;
        public function __construct(){
            $this->file = __DIR__.'/../fake_db.json';
            if(!file_exists($this->file)){
                file_put_contents($this->file, json_encode([
                    'users'=>[
                        ['id'=>1,'name'=>'Administrator','email'=>'admin@college.edu','password'=>password_hash('Admin@123', PASSWORD_DEFAULT),'role'=>'admin','is_active'=>1],
                        ['id'=>2,'name'=>'Demo Student','email'=>'student@college.edu','password'=>password_hash('Student@123', PASSWORD_DEFAULT),'role'=>'student','is_active'=>1]
                    ],
                    'complaints'=>[]
                ]));
            }
        }
        public function prepare($sql){ return new FakeStmt($this->file, $sql); }
        public function query($sql){
            $data = json_decode(file_get_contents($this->file), true);
            if(stripos($sql,'COUNT(*)')!==false){
                return new FakeResult(count($data['complaints']??[]));
            }
            return new FakeResult([]);
        }
        public function lastInsertId(){ return rand(100,999); }
    }
    class FakeStmt {
        public $file; public $sql; public $params=[];
        public function __construct($f,$s){ $this->file=$f; $this->sql=$s; }
        public function execute($p=[]){ $this->params=$p; return true; }
        public function fetch(){
            $data = json_decode(file_get_contents($this->file), true);
            $email = $this->params[0]?? '';
            foreach($data['users'] as $u){ if(strtolower($u['email'])==strtolower($email)) return $u; }
            if(stripos($this->sql,'complaints')!==false) return false;
            return false;
        }
        public function fetchAll(){
            $data = json_decode(file_get_contents($this->file), true);
            if(stripos($this->sql,'complaints')!==false) return $data['complaints']??[];
            if(stripos($this->sql,'users')!==false) return $data['users']??[];
            return [];
        }
        public function fetchColumn(){ return 0; }
    }
    class FakeResult {
        public $val;
        public function __construct($v){ $this->val=$v; }
        public function fetchColumn(){ return $this->val; }
        public function fetchAll(){ return []; }
    }
    $conn = new FakeDB();
}
?>
