<?php
if (session_status()===PHP_SESSION_NONE) session_start();
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/includes/functions.php';
if (is_logged_in()) { header('Location: ./'.($_SESSION['user_role']==='admin'? 'admin/dashboard.php' : 'dashboard.php')); exit; }
$error=''; $info='';
if (isset($_GET['registered'])) $info='Account created! Please log in.';
if ($f=get_flash()){ if($f['type']==='success') $info=$f['message']; else $error=$f['message']; }
$oldEmail='';
if ($_SERVER['REQUEST_METHOD']==='POST'){
 if(!verify_csrf($_POST['csrf_token']??null)) $error='Security check failed.';
 else{
  $email=trim($_POST['email']??''); $pass=$_POST['password']??''; $oldEmail=$email;
  if($email===''||$pass==='') $error='Enter both fields.';
  else{
   $stmt=$conn->prepare('SELECT id, name, email, password, role, is_active FROM users WHERE email =? LIMIT 1');
   $stmt->execute([$email]);
   $user=$stmt->fetch();
   if(!$user ||!password_verify($pass,$user['password'])) $error='Invalid email or password.';
   else{
    $_SESSION['user_id']=(int)$user['id']; $_SESSION['user_name']=$user['name']; $_SESSION['user_role']=$user['role']; $_SESSION['csrf_token']=bin2hex(random_bytes(32));
    header('Location: ./'.($user['role']==='admin'? 'admin/dashboard.php' : 'dashboard.php')); exit;
   }
  }
 }
}
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Login - ResolveDesk</title><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,sans-serif;background:#f6f7fb;color:#1a1a}.auth-wrap{display:flex;min-height:100vh}.auth-side{width:45%;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;padding:60px;display:flex;flex-direction:column;justify-content:center}.auth-side h1{font-size:42px;margin:20px 0 10px}.auth-main{flex:1;display:flex;align-items:center;justify-content:center;padding:30px}.auth-card{background:#fff;width:100%;max-width:420px;padding:32px;border-radius:16px;box-shadow:0 10px 40px rgba(0,0,0,.1)}.field{display:flex;flex-direction:column;margin:14px 0}.field span{font-weight:600;margin-bottom:6px}.field input{padding:12px 14px;border:1px solid #ddd;border-radius:10px;font-size:15px}.btn{padding:12px 18px;border:0;border-radius:10px;font-weight:700;cursor:pointer}.btn-primary{background:#667eea;color:#fff;width:100%}.alert{padding:12px;border-radius:10px;margin:10px 0}.alert-error{background:#fee2e2;color:#991b1b}.alert-success{background:#dcfce7;color:#166534}.demo-box{margin-top:24px;background:rgba(255,255,255,.15);padding:14px;border-radius:12px}.demo-box code{display:block;background:rgba(0,0,0,.2);padding:6px 8px;border-radius:6px;margin:4px 0;font-size:12px}
@media(max-width:800px){.auth-side{display:none}}
</style></head><body class="auth-body"><div class="auth-wrap"><div class="auth-side"><h1>Welcome back</h1><p>Login to ResolveDesk - College Complaint System</p><div class="demo-box"><p><strong>Demo Accounts</strong></p><code>admin@college.edu / Admin@123</code><code>student@college.edu / Student@123</code></div></div><div class="auth-main"><div class="auth-card"><h2>Login</h2><?php if($info):?><div class="alert alert-success"><?= e($info)?></div><?php endif;?><?php if($error):?><div class="alert alert-error"><?= e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token())?>"><label class="field"><span>Email</span><input type="email" name="email" value="<?= e($oldEmail)?>" placeholder="admin@college.edu" required></label><label class="field"><span>Password</span><input type="password" name="password" placeholder="••••••••" required></label><button class="btn btn-primary" type="submit">Login</button></form><p style="text-align:center;margin-top:14px">New? <a href="register.php">Create account</a></p></div></div></div></body></html>
